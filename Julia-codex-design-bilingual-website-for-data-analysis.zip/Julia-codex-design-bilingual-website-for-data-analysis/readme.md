# 时空数字底座数据分析处理站点 / Spatio-Temporal Digital Base

A bilingual landing site for ecology-focused data science that combines mathematics and computing to publish code, datasets, workflows, and discussions. Designed for GitHub Pages deployment with CI-friendly structure.

## Structure
- `index.html` – main bilingual landing page with mission, workflow, resources, and discussion sections.
- `assets/css/style.css` – styling inspired by modern scientific tooling sites.
- `assets/js/main.js` – smooth in-page navigation enhancements.

## Deploying to GitHub Pages
1. Fork this repository.
2. Enable GitHub Pages from `Settings → Pages` (use the `main` branch root).
3. Optionally add GitHub Actions for linting/build previews.

Contributions are welcome via Issues and Discussions.
