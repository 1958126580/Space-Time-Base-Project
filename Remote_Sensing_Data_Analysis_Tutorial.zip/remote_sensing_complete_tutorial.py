#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
================================================================================
COMPREHENSIVE REMOTE SENSING DATA ANALYSIS TUTORIAL
================================================================================

This tutorial provides a complete learning experience for remote sensing data 
analysis, covering all major topics from data acquisition to classification 
accuracy assessment. It includes simulated data generation, preprocessing, 
image enhancement, supervised classification, deep learning methods, and 
accuracy evaluation.

Author: Remote Sensing Learning Materials
Python Version: 3.8+
Required Libraries: numpy, matplotlib, scipy, scikit-learn, scikit-image

================================================================================
TABLE OF CONTENTS
================================================================================
1. Introduction and Data Simulation
2. Remote Sensing Image Properties and Visualization
3. Image Preprocessing (Radiometric and Geometric Correction)
4. Image Enhancement Techniques
5. Spectral Indices Calculation (NDVI, NDWI, NDBI)
6. Supervised Classification Algorithms
7. Deep Learning with Convolutional Neural Networks
8. Post-Classification Processing
9. Accuracy Assessment and Confusion Matrix
================================================================================
"""

# =============================================================================
# SECTION 1: LIBRARY IMPORTS AND CONFIGURATION
# =============================================================================
# Import all necessary libraries for remote sensing data analysis
# These libraries provide essential functions for array manipulation, 
# visualization, image processing, machine learning, and statistical analysis

import numpy as np                          # Numerical computing and array operations
import matplotlib.pyplot as plt             # Data visualization and plotting
import matplotlib.colors as mcolors         # Custom color map creation
from matplotlib.patches import Patch        # Legend creation for classification maps
from scipy import ndimage                   # Image filtering and convolution operations
from scipy.ndimage import uniform_filter    # Spatial filtering functions
from sklearn.model_selection import train_test_split  # Dataset splitting
from sklearn.preprocessing import StandardScaler      # Feature normalization
from sklearn.svm import SVC                           # Support Vector Machine classifier
from sklearn.ensemble import RandomForestClassifier   # Random Forest classifier
from sklearn.tree import DecisionTreeClassifier       # Decision Tree classifier
from sklearn.naive_bayes import GaussianNB            # Naive Bayes classifier
from sklearn.neighbors import KNeighborsClassifier    # K-Nearest Neighbors classifier
from sklearn.metrics import (confusion_matrix, accuracy_score, 
                            classification_report, cohen_kappa_score)
from sklearn.decomposition import PCA                 # Principal Component Analysis
from skimage import exposure                          # Image enhancement functions
import warnings
warnings.filterwarnings('ignore')           # Suppress warnings for cleaner output

# Set random seed for reproducibility
# This ensures that all random operations produce the same results each time
np.random.seed(42)

print("=" * 80)
print("REMOTE SENSING DATA ANALYSIS - COMPREHENSIVE TUTORIAL")
print("=" * 80)
print("\nAll libraries loaded successfully!")
print("This tutorial will guide you through complete remote sensing analysis.\n")

# =============================================================================
# SECTION 2: SIMULATED MULTISPECTRAL REMOTE SENSING DATA GENERATION
# =============================================================================
"""
THEORETICAL BACKGROUND:
-----------------------
Remote sensing images are acquired by sensors on satellites or aircraft that 
measure electromagnetic radiation reflected or emitted from Earth's surface.

Multispectral sensors capture data in multiple discrete wavelength bands:
- Blue band (450-520 nm): Water penetration, atmospheric scattering detection
- Green band (520-600 nm): Vegetation vigor, peak reflectance
- Red band (630-690 nm): Chlorophyll absorption, vegetation discrimination
- Near-Infrared (NIR, 760-900 nm): Vegetation health, biomass estimation
- Shortwave Infrared (SWIR, 1550-1750 nm): Moisture content, soil/vegetation

Different land cover types have characteristic spectral signatures:
- Vegetation: Low red reflectance (chlorophyll absorption), high NIR reflectance
- Water: Very low reflectance across all bands, especially in NIR
- Urban/Built-up: Moderate reflectance across all bands, relatively flat curve
- Bare Soil: Increasing reflectance from visible to NIR
- Snow/Ice: Very high reflectance in visible, decreasing in NIR
"""

def generate_simulated_remote_sensing_data(rows=512, cols=512, num_bands=6):
    """
    Generate realistic simulated multispectral remote sensing data.
    
    This function creates synthetic satellite imagery that mimics the spectral 
    characteristics of real Landsat-8 or Sentinel-2 data. The simulation includes
    five land cover classes with realistic spectral signatures and spatial patterns.
    
    Parameters:
    -----------
    rows : int
        Number of rows (height) in the simulated image (default: 512)
    cols : int
        Number of columns (width) in the simulated image (default: 512)
    num_bands : int
        Number of spectral bands to simulate (default: 6)
        Bands represent: Blue, Green, Red, NIR, SWIR1, SWIR2
    
    Returns:
    --------
    image : numpy.ndarray
        Simulated multispectral image with shape (rows, cols, num_bands)
        Values represent surface reflectance scaled from 0 to 10000
    ground_truth : numpy.ndarray
        Ground truth land cover classification with shape (rows, cols)
        Classes: 0=Water, 1=Forest, 2=Agriculture, 3=Urban, 4=Bare Soil
    
    Notes:
    ------
    The spectral signatures are based on typical values from the USGS Spectral
    Library and real satellite observations. Noise is added to simulate 
    atmospheric effects and sensor noise.
    """
    
    print("\n" + "-" * 60)
    print("GENERATING SIMULATED MULTISPECTRAL REMOTE SENSING DATA")
    print("-" * 60)
    
    # Initialize the ground truth classification map
    # This will store the true land cover class for each pixel
    ground_truth = np.zeros((rows, cols), dtype=np.int32)
    
    # Initialize the multispectral image array
    # Shape: (rows, cols, bands) - standard format for remote sensing data
    image = np.zeros((rows, cols, num_bands), dtype=np.float32)
    
    # -------------------------------------------------------------------------
    # Define spectral signatures for each land cover class
    # -------------------------------------------------------------------------
    # These values represent typical surface reflectance (scaled 0-10000)
    # for different land cover types across six spectral bands
    # Bands: [Blue, Green, Red, NIR, SWIR1, SWIR2]
    
    spectral_signatures = {
        # Water: Very low reflectance, especially in NIR and SWIR
        # Water absorbs most incoming radiation in infrared wavelengths
        0: {'name': 'Water', 
            'mean': [800, 700, 500, 200, 100, 80],
            'std': [100, 100, 80, 50, 30, 20]},
        
        # Forest: Low visible (chlorophyll absorption), high NIR (leaf structure)
        # The sharp increase from Red to NIR is called the "red edge"
        1: {'name': 'Forest', 
            'mean': [400, 800, 600, 4500, 2500, 1500],
            'std': [80, 150, 120, 500, 400, 300]},
        
        # Agriculture/Crops: Similar to forest but with different NIR response
        # Varies significantly with crop type and growth stage
        2: {'name': 'Agriculture', 
            'mean': [500, 1200, 900, 5000, 3000, 1800],
            'std': [100, 200, 150, 600, 450, 350]},
        
        # Urban/Built-up: Relatively flat spectral curve
        # Materials like concrete and asphalt have moderate uniform reflectance
        3: {'name': 'Urban', 
            'mean': [1500, 1800, 2200, 2800, 3200, 2800],
            'std': [300, 350, 400, 450, 500, 450]},
        
        # Bare Soil: Increasing reflectance from visible to SWIR
        # Soil reflectance depends on moisture, organic matter, and mineralogy
        4: {'name': 'Bare Soil', 
            'mean': [1200, 1600, 2000, 2800, 3500, 3200],
            'std': [250, 300, 350, 400, 500, 450]}
    }
    
    # -------------------------------------------------------------------------
    # Create spatial patterns for each land cover class
    # -------------------------------------------------------------------------
    # We use geometric shapes and gradients to create realistic spatial 
    # distributions of land cover types
    
    print("Creating spatial patterns for land cover classes...")
    
    # Create coordinate grids for spatial pattern generation
    y_coords, x_coords = np.ogrid[:rows, :cols]
    
    # CLASS 0: WATER - Create river and lake features
    # Rivers are linear features, lakes are circular/irregular
    # Create a meandering river through the image
    river_center = cols // 4 + 50 * np.sin(2 * np.pi * y_coords / rows * 3)
    river_mask = np.abs(x_coords - river_center) < 15
    
    # Add a lake in the upper portion of the image
    lake_center = (rows // 4, cols * 3 // 4)
    lake_distance = np.sqrt((y_coords - lake_center[0])**2 + 
                           (x_coords - lake_center[1])**2)
    lake_mask = lake_distance < 50
    
    # Combine water features
    water_mask = river_mask | lake_mask
    ground_truth[water_mask] = 0
    
    # CLASS 1: FOREST - Create forested areas in mountainous regions
    # Forests typically occupy hillsides and areas away from human activity
    forest_mask = ((x_coords > cols * 0.6) & (y_coords < rows * 0.5) & 
                   ~water_mask)
    # Add some forest patches using Perlin-like noise
    forest_noise = np.random.rand(rows, cols) > 0.6
    forest_noise = ndimage.binary_dilation(forest_noise, iterations=3)
    forest_mask = forest_mask | (forest_noise & (x_coords > cols * 0.5) & 
                                 ~water_mask & (y_coords > rows * 0.6))
    ground_truth[forest_mask] = 1
    
    # CLASS 2: AGRICULTURE - Create agricultural fields
    # Agricultural areas typically have regular, geometric patterns
    # Create rectangular field patterns
    field_pattern = ((x_coords // 60) % 2 == (y_coords // 60) % 2)
    agriculture_mask = (field_pattern & (y_coords > rows * 0.3) & 
                       (y_coords < rows * 0.8) & (x_coords < cols * 0.5) &
                       ~water_mask & ~forest_mask)
    ground_truth[agriculture_mask] = 2
    
    # CLASS 3: URBAN - Create urban/built-up areas
    # Urban areas are typically clustered and have distinct boundaries
    # Create a city center and suburban spread
    city_center = (rows * 0.5, cols * 0.3)
    city_distance = np.sqrt((y_coords - city_center[0])**2 + 
                           (x_coords - city_center[1])**2)
    urban_mask = (city_distance < 80) & ~water_mask
    # Add road network radiating from city
    road_mask = (np.abs(x_coords - cols * 0.3) < 8) | (np.abs(y_coords - rows * 0.5) < 8)
    urban_mask = urban_mask | (road_mask & ~water_mask & ~forest_mask)
    ground_truth[urban_mask] = 3
    
    # CLASS 4: BARE SOIL - Remaining areas
    # Bare soil fills the remaining unclassified areas
    bare_soil_mask = (ground_truth == 0) & ~water_mask
    # Override only truly unassigned pixels
    unassigned = ~water_mask & ~forest_mask & ~agriculture_mask & ~urban_mask
    ground_truth[unassigned] = 4
    
    # -------------------------------------------------------------------------
    # Generate spectral values based on class assignments
    # -------------------------------------------------------------------------
    print("Generating spectral signatures for each pixel...")
    
    for class_id, properties in spectral_signatures.items():
        # Find all pixels belonging to this class
        class_pixels = ground_truth == class_id
        num_pixels = np.sum(class_pixels)
        
        if num_pixels > 0:
            # Generate spectral values for each band
            for band_idx in range(num_bands):
                # Create values from normal distribution with class-specific
                # mean and standard deviation
                band_values = np.random.normal(
                    loc=properties['mean'][band_idx],
                    scale=properties['std'][band_idx],
                    size=num_pixels
                )
                # Assign values to the image
                image[class_pixels, band_idx] = band_values
            
            print(f"  - {properties['name']}: {num_pixels:,} pixels generated")
    
    # -------------------------------------------------------------------------
    # Add realistic noise and atmospheric effects
    # -------------------------------------------------------------------------
    print("Adding atmospheric noise and sensor effects...")
    
    # Add Gaussian noise to simulate sensor noise
    sensor_noise = np.random.normal(0, 50, image.shape)
    image = image + sensor_noise
    
    # Add slight atmospheric haze effect (affects shorter wavelengths more)
    haze = np.random.normal(100, 30, (rows, cols))
    for band_idx in range(num_bands):
        # Haze effect decreases with wavelength
        haze_factor = 1.0 - (band_idx / num_bands) * 0.5
        image[:, :, band_idx] += haze * haze_factor
    
    # Ensure all values are positive and within valid range
    image = np.clip(image, 0, 10000)
    
    # -------------------------------------------------------------------------
    # Add striping noise (simulates detector array inconsistencies)
    # -------------------------------------------------------------------------
    # This is common in push-broom sensors like Landsat
    stripe_pattern = np.random.normal(0, 30, cols)
    for band_idx in range(num_bands):
        image[:, :, band_idx] += stripe_pattern
    
    image = np.clip(image, 0, 10000)
    
    print("\nSimulated data generation complete!")
    print(f"  - Image shape: {image.shape}")
    print(f"  - Ground truth shape: {ground_truth.shape}")
    print(f"  - Number of classes: {len(np.unique(ground_truth))}")
    print(f"  - Value range: [{image.min():.1f}, {image.max():.1f}]")
    
    return image, ground_truth

# Generate the simulated remote sensing data
image_data, ground_truth_data = generate_simulated_remote_sensing_data()

# Define class names and colors for visualization
CLASS_NAMES = ['Water', 'Forest', 'Agriculture', 'Urban', 'Bare Soil']
CLASS_COLORS = ['#0077be', '#228b22', '#90ee90', '#ff6b6b', '#d4a574']

# =============================================================================
# SECTION 3: DATA VISUALIZATION AND EXPLORATION
# =============================================================================
"""
THEORETICAL BACKGROUND:
-----------------------
Visualization is crucial in remote sensing for:
1. Quality assessment of acquired data
2. Initial interpretation of land cover patterns
3. Verification of processing results
4. Communication of findings

Common visualization techniques include:
- True color composite: Red, Green, Blue bands displayed as RGB
- False color composite: NIR, Red, Green displayed as RGB
- Single band grayscale display
- Spectral profiles/signatures
"""

def visualize_remote_sensing_data(image, ground_truth, class_names, class_colors):
    """
    Create comprehensive visualizations of remote sensing data.
    
    This function generates multiple plots to help understand the spectral
    and spatial characteristics of the remote sensing data, including:
    - True color and false color composites
    - Individual band displays
    - Ground truth classification map
    - Histograms of band values
    - Spectral signature plots
    
    Parameters:
    -----------
    image : numpy.ndarray
        Multispectral image with shape (rows, cols, bands)
    ground_truth : numpy.ndarray
        Ground truth classification map
    class_names : list
        Names of land cover classes
    class_colors : list
        Colors for each class in hex format
    
    Returns:
    --------
    None (displays plots)
    """
    
    print("\n" + "-" * 60)
    print("VISUALIZING REMOTE SENSING DATA")
    print("-" * 60)
    
    # -------------------------------------------------------------------------
    # Helper function for contrast enhancement
    # -------------------------------------------------------------------------
    def enhance_contrast(band, percentile_low=2, percentile_high=98):
        """
        Apply percentile-based contrast stretching to enhance visualization.
        
        This technique improves the visual appearance by stretching the 
        histogram of the image to utilize the full display range (0-1).
        
        Parameters:
        -----------
        band : numpy.ndarray
            Single band image data
        percentile_low : float
            Lower percentile for clipping (default: 2)
        percentile_high : float
            Upper percentile for clipping (default: 98)
        
        Returns:
        --------
        numpy.ndarray
            Contrast-enhanced band normalized to [0, 1]
        """
        # Calculate percentile values for clipping
        p_low = np.percentile(band, percentile_low)
        p_high = np.percentile(band, percentile_high)
        
        # Clip and normalize to [0, 1]
        band_clipped = np.clip(band, p_low, p_high)
        band_normalized = (band_clipped - p_low) / (p_high - p_low + 1e-10)
        
        return band_normalized
    
    # Create figure with multiple subplots
    fig = plt.figure(figsize=(20, 16))
    
    # -------------------------------------------------------------------------
    # Plot 1: True Color Composite (Bands 3, 2, 1 as R, G, B)
    # -------------------------------------------------------------------------
    ax1 = fig.add_subplot(2, 3, 1)
    
    # Extract and enhance red, green, blue bands
    # Band indices: 0=Blue, 1=Green, 2=Red (following Landsat convention)
    red = enhance_contrast(image[:, :, 2])
    green = enhance_contrast(image[:, :, 1])
    blue = enhance_contrast(image[:, :, 0])
    
    # Stack bands to create RGB composite
    true_color = np.dstack([red, green, blue])
    
    ax1.imshow(true_color)
    ax1.set_title('True Color Composite\n(Red-Green-Blue)', fontsize=12, fontweight='bold')
    ax1.axis('off')
    
    # -------------------------------------------------------------------------
    # Plot 2: False Color Composite (NIR, Red, Green as R, G, B)
    # -------------------------------------------------------------------------
    ax2 = fig.add_subplot(2, 3, 2)
    
    # False color composite emphasizes vegetation
    # Healthy vegetation appears bright red due to high NIR reflectance
    nir = enhance_contrast(image[:, :, 3])
    
    false_color = np.dstack([nir, red, green])
    
    ax2.imshow(false_color)
    ax2.set_title('False Color Composite\n(NIR-Red-Green)', fontsize=12, fontweight='bold')
    ax2.axis('off')
    
    # -------------------------------------------------------------------------
    # Plot 3: Ground Truth Classification Map
    # -------------------------------------------------------------------------
    ax3 = fig.add_subplot(2, 3, 3)
    
    # Create custom colormap for classification display
    cmap = mcolors.ListedColormap(class_colors)
    bounds = np.arange(-0.5, len(class_names), 1)
    norm = mcolors.BoundaryNorm(bounds, cmap.N)
    
    im = ax3.imshow(ground_truth, cmap=cmap, norm=norm)
    ax3.set_title('Ground Truth Classification', fontsize=12, fontweight='bold')
    ax3.axis('off')
    
    # Add legend
    legend_patches = [Patch(facecolor=class_colors[i], label=class_names[i]) 
                      for i in range(len(class_names))]
    ax3.legend(handles=legend_patches, loc='lower right', fontsize=8)
    
    # -------------------------------------------------------------------------
    # Plot 4: Individual Band Display (NIR band)
    # -------------------------------------------------------------------------
    ax4 = fig.add_subplot(2, 3, 4)
    
    nir_display = enhance_contrast(image[:, :, 3])
    ax4.imshow(nir_display, cmap='gray')
    ax4.set_title('Near-Infrared (NIR) Band\n(Band 4)', fontsize=12, fontweight='bold')
    ax4.axis('off')
    
    # -------------------------------------------------------------------------
    # Plot 5: Histogram of All Bands
    # -------------------------------------------------------------------------
    ax5 = fig.add_subplot(2, 3, 5)
    
    band_names = ['Blue', 'Green', 'Red', 'NIR', 'SWIR1', 'SWIR2']
    band_colors_hist = ['blue', 'green', 'red', 'darkred', 'brown', 'saddlebrown']
    
    for band_idx in range(image.shape[2]):
        # Sample data for faster histogram computation
        sample_data = image[:, :, band_idx].flatten()[::10]
        ax5.hist(sample_data, bins=50, alpha=0.5, label=band_names[band_idx],
                color=band_colors_hist[band_idx], density=True)
    
    ax5.set_xlabel('Reflectance Value', fontsize=10)
    ax5.set_ylabel('Frequency (Normalized)', fontsize=10)
    ax5.set_title('Spectral Band Histograms', fontsize=12, fontweight='bold')
    ax5.legend(fontsize=8)
    ax5.grid(True, alpha=0.3)
    
    # -------------------------------------------------------------------------
    # Plot 6: Mean Spectral Signatures by Class
    # -------------------------------------------------------------------------
    ax6 = fig.add_subplot(2, 3, 6)
    
    wavelengths = [485, 560, 660, 830, 1650, 2220]  # Approximate wavelengths in nm
    
    for class_id in range(len(class_names)):
        # Extract pixels belonging to this class
        class_mask = ground_truth == class_id
        class_pixels = image[class_mask]
        
        # Calculate mean and standard deviation for each band
        mean_spectrum = np.mean(class_pixels, axis=0)
        std_spectrum = np.std(class_pixels, axis=0)
        
        # Plot mean with error bars
        ax6.errorbar(wavelengths, mean_spectrum, yerr=std_spectrum,
                    label=class_names[class_id], color=class_colors[class_id],
                    marker='o', capsize=3, linewidth=2, markersize=6)
    
    ax6.set_xlabel('Wavelength (nm)', fontsize=10)
    ax6.set_ylabel('Reflectance', fontsize=10)
    ax6.set_title('Mean Spectral Signatures by Class', fontsize=12, fontweight='bold')
    ax6.legend(fontsize=8)
    ax6.grid(True, alpha=0.3)
    
    plt.tight_layout()
    plt.savefig('01_data_visualization.png', dpi=150, bbox_inches='tight')
    plt.close()
    
    print("Visualization complete! Saved as '01_data_visualization.png'")

# Generate visualizations
visualize_remote_sensing_data(image_data, ground_truth_data, CLASS_NAMES, CLASS_COLORS)

# =============================================================================
# SECTION 4: IMAGE PREPROCESSING
# =============================================================================
"""
THEORETICAL BACKGROUND:
-----------------------
Image preprocessing is essential to ensure data quality and consistency before
analysis. The main preprocessing steps include:

1. RADIOMETRIC CORRECTION
   - Calibration: Convert raw digital numbers (DN) to radiance or reflectance
   - Atmospheric correction: Remove atmospheric scattering and absorption effects
   - Sun angle correction: Account for solar illumination geometry
   - Sensor noise removal: Reduce striping and random noise

2. GEOMETRIC CORRECTION
   - Orthorectification: Correct terrain-induced distortions
   - Image registration: Align images from different dates/sensors
   - Georeferencing: Assign geographic coordinates to pixels
   
3. NOISE REDUCTION
   - Destriping: Remove systematic sensor noise patterns
   - Filtering: Smooth random noise while preserving edges
"""

def radiometric_preprocessing(image):
    """
    Perform radiometric preprocessing on remote sensing imagery.
    
    This function simulates common radiometric corrections including:
    - Conversion from DN to reflectance (simplified)
    - Destriping to remove sensor artifacts
    - Noise reduction using adaptive filtering
    
    Parameters:
    -----------
    image : numpy.ndarray
        Input multispectral image with shape (rows, cols, bands)
    
    Returns:
    --------
    corrected_image : numpy.ndarray
        Radiometrically corrected image
    """
    
    print("\n" + "-" * 60)
    print("PERFORMING RADIOMETRIC PREPROCESSING")
    print("-" * 60)
    
    corrected_image = image.copy().astype(np.float32)
    
    # -------------------------------------------------------------------------
    # Step 1: Destriping - Remove systematic sensor noise
    # -------------------------------------------------------------------------
    # Striping occurs when different detectors in a sensor array have 
    # slightly different responses. We correct this by normalizing each
    # column to match the global statistics.
    
    print("Step 1: Destriping correction...")
    
    for band_idx in range(corrected_image.shape[2]):
        band = corrected_image[:, :, band_idx]
        
        # Calculate column means
        col_means = np.mean(band, axis=0)
        
        # Calculate global mean
        global_mean = np.mean(band)
        
        # Calculate correction factors
        correction = global_mean - col_means
        
        # Apply correction
        corrected_image[:, :, band_idx] = band + correction
    
    # -------------------------------------------------------------------------
    # Step 2: Normalize to 0-1 range (simulate TOA reflectance conversion)
    # -------------------------------------------------------------------------
    # In real applications, this would involve using calibration coefficients
    # from the sensor metadata to convert DN to Top-of-Atmosphere reflectance
    
    print("Step 2: Converting to reflectance units...")
    
    # Simple min-max normalization for simulation
    for band_idx in range(corrected_image.shape[2]):
        band = corrected_image[:, :, band_idx]
        band_min = np.percentile(band, 1)
        band_max = np.percentile(band, 99)
        corrected_image[:, :, band_idx] = (band - band_min) / (band_max - band_min + 1e-10)
    
    # Clip to valid range [0, 1]
    corrected_image = np.clip(corrected_image, 0, 1)
    
    # -------------------------------------------------------------------------
    # Step 3: Atmospheric haze reduction using Dark Object Subtraction
    # -------------------------------------------------------------------------
    # Dark Object Subtraction (DOS) is a simple atmospheric correction method
    # that assumes the darkest pixels in the image should have zero reflectance
    
    print("Step 3: Atmospheric correction (Dark Object Subtraction)...")
    
    for band_idx in range(corrected_image.shape[2]):
        band = corrected_image[:, :, band_idx]
        
        # Find the dark object value (1st percentile)
        dark_value = np.percentile(band, 1)
        
        # Subtract dark object value (haze component)
        corrected_image[:, :, band_idx] = band - dark_value
    
    # Clip to valid range
    corrected_image = np.clip(corrected_image, 0, 1)
    
    # -------------------------------------------------------------------------
    # Step 4: Apply noise reduction filter
    # -------------------------------------------------------------------------
    # Use a gentle median filter to reduce random noise while preserving edges
    
    print("Step 4: Applying noise reduction filter...")
    
    for band_idx in range(corrected_image.shape[2]):
        # Apply 3x3 median filter
        corrected_image[:, :, band_idx] = ndimage.median_filter(
            corrected_image[:, :, band_idx], size=3
        )
    
    print("\nRadiometric preprocessing complete!")
    print(f"  - Output value range: [{corrected_image.min():.4f}, {corrected_image.max():.4f}]")
    
    return corrected_image


def geometric_preprocessing(image, rotation_angle=2.0, translation=(5, 3)):
    """
    Demonstrate geometric preprocessing operations.
    
    This function simulates common geometric corrections:
    - Rotation correction (simulating satellite attitude errors)
    - Translation/shift correction (simulating georeferencing errors)
    
    Parameters:
    -----------
    image : numpy.ndarray
        Input image to be geometrically corrected
    rotation_angle : float
        Rotation angle in degrees to correct (default: 2.0)
    translation : tuple
        (y, x) translation in pixels to correct (default: (5, 3))
    
    Returns:
    --------
    corrected_image : numpy.ndarray
        Geometrically corrected image
    """
    
    print("\n" + "-" * 60)
    print("DEMONSTRATING GEOMETRIC PREPROCESSING")
    print("-" * 60)
    
    corrected_image = np.zeros_like(image)
    
    # -------------------------------------------------------------------------
    # Step 1: Apply rotation correction
    # -------------------------------------------------------------------------
    print(f"Step 1: Correcting rotation of {rotation_angle} degrees...")
    
    for band_idx in range(image.shape[2]):
        # Rotate image to correct for satellite attitude
        corrected_image[:, :, band_idx] = ndimage.rotate(
            image[:, :, band_idx],
            angle=-rotation_angle,  # Negative to correct
            reshape=False,
            mode='constant',
            cval=0
        )
    
    # -------------------------------------------------------------------------
    # Step 2: Apply translation correction
    # -------------------------------------------------------------------------
    print(f"Step 2: Correcting translation of {translation} pixels...")
    
    for band_idx in range(corrected_image.shape[2]):
        # Shift image to correct for georeferencing errors
        corrected_image[:, :, band_idx] = ndimage.shift(
            corrected_image[:, :, band_idx],
            shift=(-translation[0], -translation[1]),  # Negative to correct
            mode='constant',
            cval=0
        )
    
    print("\nGeometric preprocessing demonstration complete!")
    
    return corrected_image

# Apply preprocessing
preprocessed_image = radiometric_preprocessing(image_data)

# Visualize preprocessing results
def visualize_preprocessing_results(original, preprocessed):
    """
    Visualize the effects of preprocessing on the image.
    
    Parameters:
    -----------
    original : numpy.ndarray
        Original image before preprocessing
    preprocessed : numpy.ndarray
        Image after preprocessing
    """
    
    fig, axes = plt.subplots(2, 3, figsize=(15, 10))
    
    # Normalize original for display
    def normalize_band(band):
        return (band - band.min()) / (band.max() - band.min() + 1e-10)
    
    # Original NIR band
    axes[0, 0].imshow(normalize_band(original[:, :, 3]), cmap='gray')
    axes[0, 0].set_title('Original NIR Band', fontsize=12, fontweight='bold')
    axes[0, 0].axis('off')
    
    # Preprocessed NIR band
    axes[0, 1].imshow(preprocessed[:, :, 3], cmap='gray')
    axes[0, 1].set_title('Preprocessed NIR Band', fontsize=12, fontweight='bold')
    axes[0, 1].axis('off')
    
    # Difference map
    diff = normalize_band(original[:, :, 3]) - preprocessed[:, :, 3]
    axes[0, 2].imshow(diff, cmap='RdBu', vmin=-0.1, vmax=0.1)
    axes[0, 2].set_title('Difference (Original - Preprocessed)', fontsize=12, fontweight='bold')
    axes[0, 2].axis('off')
    
    # Original histogram
    axes[1, 0].hist(original[:, :, 3].flatten()[::10], bins=50, color='blue', alpha=0.7)
    axes[1, 0].set_title('Original NIR Histogram', fontsize=12, fontweight='bold')
    axes[1, 0].set_xlabel('Value')
    axes[1, 0].set_ylabel('Frequency')
    
    # Preprocessed histogram
    axes[1, 1].hist(preprocessed[:, :, 3].flatten()[::10], bins=50, color='green', alpha=0.7)
    axes[1, 1].set_title('Preprocessed NIR Histogram', fontsize=12, fontweight='bold')
    axes[1, 1].set_xlabel('Value')
    axes[1, 1].set_ylabel('Frequency')
    
    # Column profile comparison (to show destriping effect)
    col_means_orig = np.mean(original[:, :, 3], axis=0)
    col_means_prep = np.mean(preprocessed[:, :, 3], axis=0) * original[:, :, 3].max()
    
    axes[1, 2].plot(col_means_orig[:100], label='Original', alpha=0.7)
    axes[1, 2].plot(col_means_prep[:100], label='Preprocessed', alpha=0.7)
    axes[1, 2].set_title('Column Mean Profile (First 100 columns)', fontsize=12, fontweight='bold')
    axes[1, 2].set_xlabel('Column')
    axes[1, 2].set_ylabel('Mean Value')
    axes[1, 2].legend()
    axes[1, 2].grid(True, alpha=0.3)
    
    plt.tight_layout()
    plt.savefig('02_preprocessing_results.png', dpi=150, bbox_inches='tight')
    plt.close()
    
    print("Preprocessing visualization saved as '02_preprocessing_results.png'")

visualize_preprocessing_results(image_data, preprocessed_image)

# =============================================================================
# SECTION 5: IMAGE ENHANCEMENT TECHNIQUES
# =============================================================================
"""
THEORETICAL BACKGROUND:
-----------------------
Image enhancement improves the visual quality and interpretability of remote
sensing images without adding new information. Key techniques include:

1. CONTRAST ENHANCEMENT
   - Linear stretching: Expand dynamic range to full display range
   - Histogram equalization: Redistribute pixel values for uniform histogram
   - Gamma correction: Non-linear transformation for brightness adjustment

2. SPATIAL FILTERING
   - Low-pass filters: Smooth noise and reduce high-frequency details
   - High-pass filters: Enhance edges and fine details
   - Band-pass filters: Enhance specific spatial frequencies

3. SPECTRAL ENHANCEMENT
   - Band ratios: Highlight specific features through band division
   - Principal Component Analysis (PCA): Reduce dimensionality
   - Spectral indices: NDVI, NDWI, NDBI for specific applications
"""

def calculate_spectral_indices(image):
    """
    Calculate common spectral indices used in remote sensing.
    
    Spectral indices combine multiple bands to highlight specific land cover
    characteristics. This function calculates several widely-used indices:
    
    Parameters:
    -----------
    image : numpy.ndarray
        Preprocessed multispectral image with shape (rows, cols, bands)
        Expected band order: Blue(0), Green(1), Red(2), NIR(3), SWIR1(4), SWIR2(5)
    
    Returns:
    --------
    indices : dict
        Dictionary containing calculated spectral indices:
        - 'NDVI': Normalized Difference Vegetation Index
        - 'NDWI': Normalized Difference Water Index
        - 'NDBI': Normalized Difference Built-up Index
        - 'SAVI': Soil Adjusted Vegetation Index
        - 'EVI': Enhanced Vegetation Index
    """
    
    print("\n" + "-" * 60)
    print("CALCULATING SPECTRAL INDICES")
    print("-" * 60)
    
    # Extract individual bands for clarity
    # Using small epsilon to prevent division by zero
    eps = 1e-10
    
    blue = image[:, :, 0] + eps
    green = image[:, :, 1] + eps
    red = image[:, :, 2] + eps
    nir = image[:, :, 3] + eps
    swir1 = image[:, :, 4] + eps
    swir2 = image[:, :, 5] + eps
    
    indices = {}
    
    # -------------------------------------------------------------------------
    # NDVI - Normalized Difference Vegetation Index
    # -------------------------------------------------------------------------
    # NDVI = (NIR - Red) / (NIR + Red)
    # Range: [-1, 1]
    # High values indicate healthy vegetation
    # Low/negative values indicate water, bare soil, or urban areas
    
    print("Calculating NDVI (Normalized Difference Vegetation Index)...")
    indices['NDVI'] = (nir - red) / (nir + red)
    print(f"  - NDVI range: [{indices['NDVI'].min():.3f}, {indices['NDVI'].max():.3f}]")
    
    # -------------------------------------------------------------------------
    # NDWI - Normalized Difference Water Index
    # -------------------------------------------------------------------------
    # NDWI = (Green - NIR) / (Green + NIR)
    # Range: [-1, 1]
    # High values indicate open water
    # Also known as McFeeters NDWI
    
    print("Calculating NDWI (Normalized Difference Water Index)...")
    indices['NDWI'] = (green - nir) / (green + nir)
    print(f"  - NDWI range: [{indices['NDWI'].min():.3f}, {indices['NDWI'].max():.3f}]")
    
    # -------------------------------------------------------------------------
    # NDBI - Normalized Difference Built-up Index
    # -------------------------------------------------------------------------
    # NDBI = (SWIR - NIR) / (SWIR + NIR)
    # Range: [-1, 1]
    # High values indicate built-up/urban areas
    # Based on the higher SWIR reflectance of urban materials
    
    print("Calculating NDBI (Normalized Difference Built-up Index)...")
    indices['NDBI'] = (swir1 - nir) / (swir1 + nir)
    print(f"  - NDBI range: [{indices['NDBI'].min():.3f}, {indices['NDBI'].max():.3f}]")
    
    # -------------------------------------------------------------------------
    # SAVI - Soil Adjusted Vegetation Index
    # -------------------------------------------------------------------------
    # SAVI = ((NIR - Red) / (NIR + Red + L)) * (1 + L)
    # where L is a soil brightness correction factor (typically 0.5)
    # Minimizes soil brightness influences on vegetation indices
    
    print("Calculating SAVI (Soil Adjusted Vegetation Index)...")
    L = 0.5  # Soil brightness correction factor
    indices['SAVI'] = ((nir - red) / (nir + red + L)) * (1 + L)
    print(f"  - SAVI range: [{indices['SAVI'].min():.3f}, {indices['SAVI'].max():.3f}]")
    
    # -------------------------------------------------------------------------
    # EVI - Enhanced Vegetation Index
    # -------------------------------------------------------------------------
    # EVI = G * ((NIR - Red) / (NIR + C1*Red - C2*Blue + L))
    # More sensitive to high biomass regions
    # Reduces atmospheric and soil background influences
    
    print("Calculating EVI (Enhanced Vegetation Index)...")
    G = 2.5    # Gain factor
    C1 = 6.0   # Coefficient for aerosol resistance (red band)
    C2 = 7.5   # Coefficient for aerosol resistance (blue band)
    L_evi = 1.0  # Canopy background adjustment
    
    indices['EVI'] = G * ((nir - red) / (nir + C1 * red - C2 * blue + L_evi))
    # Clip EVI to reasonable range
    indices['EVI'] = np.clip(indices['EVI'], -1, 1)
    print(f"  - EVI range: [{indices['EVI'].min():.3f}, {indices['EVI'].max():.3f}]")
    
    print("\nSpectral indices calculation complete!")
    
    return indices


def apply_spatial_filters(image):
    """
    Apply various spatial filters to demonstrate image enhancement.
    
    Spatial filtering uses a moving window (kernel) to process each pixel
    based on its neighborhood. This function demonstrates common filters:
    
    Parameters:
    -----------
    image : numpy.ndarray
        Input single-band image for filtering demonstration
    
    Returns:
    --------
    filtered_images : dict
        Dictionary containing filtered images:
        - 'mean': Low-pass mean filter (smoothing)
        - 'median': Median filter (noise reduction, edge-preserving)
        - 'gaussian': Gaussian smoothing filter
        - 'sobel': Sobel edge detection filter
        - 'laplacian': Laplacian edge enhancement
        - 'sharpened': Sharpened image
    """
    
    print("\n" + "-" * 60)
    print("APPLYING SPATIAL FILTERS")
    print("-" * 60)
    
    # Use NIR band for demonstration
    band = image[:, :, 3].copy()
    
    filtered_images = {}
    
    # -------------------------------------------------------------------------
    # Mean Filter (Low-pass filter)
    # -------------------------------------------------------------------------
    # Averages pixel values in a neighborhood
    # Effect: Smoothing, noise reduction, blur
    
    print("Applying mean filter (3x3)...")
    kernel_mean = np.ones((3, 3)) / 9.0
    filtered_images['mean'] = ndimage.convolve(band, kernel_mean)
    
    # -------------------------------------------------------------------------
    # Median Filter (Non-linear filter)
    # -------------------------------------------------------------------------
    # Replaces each pixel with the median of its neighborhood
    # Effect: Removes salt-and-pepper noise while preserving edges
    
    print("Applying median filter (3x3)...")
    filtered_images['median'] = ndimage.median_filter(band, size=3)
    
    # -------------------------------------------------------------------------
    # Gaussian Filter (Low-pass filter)
    # -------------------------------------------------------------------------
    # Weighted average with Gaussian distribution
    # Effect: Smooth blurring with less weight on distant pixels
    
    print("Applying Gaussian filter (sigma=1.0)...")
    filtered_images['gaussian'] = ndimage.gaussian_filter(band, sigma=1.0)
    
    # -------------------------------------------------------------------------
    # Sobel Edge Detection (High-pass filter)
    # -------------------------------------------------------------------------
    # Calculates gradient magnitude to detect edges
    # Combines horizontal and vertical gradient components
    
    print("Applying Sobel edge detection...")
    sobel_x = ndimage.sobel(band, axis=1)  # Horizontal edges
    sobel_y = ndimage.sobel(band, axis=0)  # Vertical edges
    filtered_images['sobel'] = np.hypot(sobel_x, sobel_y)  # Gradient magnitude
    
    # -------------------------------------------------------------------------
    # Laplacian Filter (Edge enhancement)
    # -------------------------------------------------------------------------
    # Second derivative operator for edge detection
    # Highlights rapid intensity changes in all directions
    
    print("Applying Laplacian filter...")
    filtered_images['laplacian'] = ndimage.laplace(band)
    
    # -------------------------------------------------------------------------
    # Image Sharpening (High-pass enhancement)
    # -------------------------------------------------------------------------
    # Enhances details by adding high-frequency components
    # Sharpened = Original + k * (Original - Smoothed)
    
    print("Creating sharpened image...")
    smoothed = ndimage.gaussian_filter(band, sigma=2.0)
    detail = band - smoothed
    filtered_images['sharpened'] = band + 1.5 * detail
    
    print("\nSpatial filtering complete!")
    
    return filtered_images


def perform_pca_analysis(image, n_components=3):
    """
    Perform Principal Component Analysis (PCA) on multispectral image.
    
    PCA transforms correlated spectral bands into uncorrelated principal 
    components, which can be useful for:
    - Data compression/dimensionality reduction
    - Noise reduction (noise typically in higher PCs)
    - Feature extraction for classification
    - Change detection
    
    Parameters:
    -----------
    image : numpy.ndarray
        Input multispectral image with shape (rows, cols, bands)
    n_components : int
        Number of principal components to retain (default: 3)
    
    Returns:
    --------
    pca_image : numpy.ndarray
        PCA-transformed image with shape (rows, cols, n_components)
    explained_variance : numpy.ndarray
        Percentage of variance explained by each component
    pca_model : PCA
        Fitted PCA model object
    """
    
    print("\n" + "-" * 60)
    print("PERFORMING PRINCIPAL COMPONENT ANALYSIS (PCA)")
    print("-" * 60)
    
    rows, cols, bands = image.shape
    
    # Reshape image to 2D array (pixels x bands) for PCA
    # Each row represents a pixel, each column represents a band
    pixels = image.reshape(-1, bands)
    
    print(f"Input shape: {image.shape}")
    print(f"Reshaped for PCA: {pixels.shape}")
    
    # Initialize and fit PCA model
    pca = PCA(n_components=n_components)
    
    print(f"Fitting PCA with {n_components} components...")
    pca_pixels = pca.fit_transform(pixels)
    
    # Reshape back to image dimensions
    pca_image = pca_pixels.reshape(rows, cols, n_components)
    
    # Get explained variance ratios
    explained_variance = pca.explained_variance_ratio_ * 100
    
    print("\nPCA Results:")
    print("-" * 40)
    cumulative = 0
    for i, var in enumerate(explained_variance):
        cumulative += var
        print(f"  PC{i+1}: {var:.2f}% variance (Cumulative: {cumulative:.2f}%)")
    
    print(f"\nTotal variance explained: {cumulative:.2f}%")
    print(f"Output shape: {pca_image.shape}")
    
    return pca_image, explained_variance, pca

# Calculate spectral indices
spectral_indices = calculate_spectral_indices(preprocessed_image)

# Apply spatial filters
filtered_images = apply_spatial_filters(preprocessed_image)

# Perform PCA
pca_image, pca_variance, pca_model = perform_pca_analysis(preprocessed_image)

# Visualize enhancement results
def visualize_enhancement_results(indices, filtered, pca_img, pca_var):
    """
    Create comprehensive visualization of image enhancement results.
    """
    
    fig = plt.figure(figsize=(20, 15))
    
    # Row 1: Spectral Indices
    ax1 = fig.add_subplot(3, 4, 1)
    im1 = ax1.imshow(indices['NDVI'], cmap='RdYlGn', vmin=-1, vmax=1)
    ax1.set_title('NDVI\n(Vegetation Index)', fontsize=11, fontweight='bold')
    ax1.axis('off')
    plt.colorbar(im1, ax=ax1, fraction=0.046)
    
    ax2 = fig.add_subplot(3, 4, 2)
    im2 = ax2.imshow(indices['NDWI'], cmap='Blues', vmin=-1, vmax=1)
    ax2.set_title('NDWI\n(Water Index)', fontsize=11, fontweight='bold')
    ax2.axis('off')
    plt.colorbar(im2, ax=ax2, fraction=0.046)
    
    ax3 = fig.add_subplot(3, 4, 3)
    im3 = ax3.imshow(indices['NDBI'], cmap='YlOrRd', vmin=-1, vmax=1)
    ax3.set_title('NDBI\n(Built-up Index)', fontsize=11, fontweight='bold')
    ax3.axis('off')
    plt.colorbar(im3, ax=ax3, fraction=0.046)
    
    ax4 = fig.add_subplot(3, 4, 4)
    im4 = ax4.imshow(indices['SAVI'], cmap='RdYlGn', vmin=-1, vmax=1)
    ax4.set_title('SAVI\n(Soil Adjusted VI)', fontsize=11, fontweight='bold')
    ax4.axis('off')
    plt.colorbar(im4, ax=ax4, fraction=0.046)
    
    # Row 2: Spatial Filters
    ax5 = fig.add_subplot(3, 4, 5)
    ax5.imshow(filtered['mean'], cmap='gray')
    ax5.set_title('Mean Filter\n(Smoothing)', fontsize=11, fontweight='bold')
    ax5.axis('off')
    
    ax6 = fig.add_subplot(3, 4, 6)
    ax6.imshow(filtered['median'], cmap='gray')
    ax6.set_title('Median Filter\n(Noise Reduction)', fontsize=11, fontweight='bold')
    ax6.axis('off')
    
    ax7 = fig.add_subplot(3, 4, 7)
    ax7.imshow(filtered['sobel'], cmap='gray')
    ax7.set_title('Sobel Filter\n(Edge Detection)', fontsize=11, fontweight='bold')
    ax7.axis('off')
    
    ax8 = fig.add_subplot(3, 4, 8)
    ax8.imshow(filtered['sharpened'], cmap='gray')
    ax8.set_title('Sharpened Image\n(Detail Enhancement)', fontsize=11, fontweight='bold')
    ax8.axis('off')
    
    # Row 3: PCA Results
    def normalize(arr):
        return (arr - arr.min()) / (arr.max() - arr.min() + 1e-10)
    
    ax9 = fig.add_subplot(3, 4, 9)
    ax9.imshow(normalize(pca_img[:, :, 0]), cmap='gray')
    ax9.set_title(f'PC1 ({pca_var[0]:.1f}% variance)', fontsize=11, fontweight='bold')
    ax9.axis('off')
    
    ax10 = fig.add_subplot(3, 4, 10)
    ax10.imshow(normalize(pca_img[:, :, 1]), cmap='gray')
    ax10.set_title(f'PC2 ({pca_var[1]:.1f}% variance)', fontsize=11, fontweight='bold')
    ax10.axis('off')
    
    ax11 = fig.add_subplot(3, 4, 11)
    ax11.imshow(normalize(pca_img[:, :, 2]), cmap='gray')
    ax11.set_title(f'PC3 ({pca_var[2]:.1f}% variance)', fontsize=11, fontweight='bold')
    ax11.axis('off')
    
    # PCA Color Composite
    ax12 = fig.add_subplot(3, 4, 12)
    pca_rgb = np.dstack([normalize(pca_img[:, :, 0]),
                         normalize(pca_img[:, :, 1]),
                         normalize(pca_img[:, :, 2])])
    ax12.imshow(pca_rgb)
    ax12.set_title('PCA Composite\n(PC1-PC2-PC3 as RGB)', fontsize=11, fontweight='bold')
    ax12.axis('off')
    
    plt.tight_layout()
    plt.savefig('03_enhancement_results.png', dpi=150, bbox_inches='tight')
    plt.close()
    
    print("\nEnhancement visualization saved as '03_enhancement_results.png'")

visualize_enhancement_results(spectral_indices, filtered_images, pca_image, pca_variance)

# =============================================================================
# SECTION 6: SUPERVISED CLASSIFICATION ALGORITHMS
# =============================================================================
"""
THEORETICAL BACKGROUND:
-----------------------
Supervised classification uses training samples with known class labels to
"teach" a classifier the spectral characteristics of each land cover type.
The trained classifier then assigns labels to all pixels in the image.

Common supervised classification algorithms:

1. MAXIMUM LIKELIHOOD CLASSIFIER (MLC)
   - Assumes Gaussian distribution for each class
   - Calculates probability of pixel belonging to each class
   - Assigns pixel to class with highest probability
   - Advantages: Well-understood theory, provides probability output
   - Disadvantages: Assumes normal distribution, sensitive to outliers

2. SUPPORT VECTOR MACHINE (SVM)
   - Finds optimal hyperplane separating classes
   - Uses kernel functions for non-linear boundaries
   - Advantages: Effective in high dimensions, robust to overfitting
   - Disadvantages: Computationally intensive, requires parameter tuning

3. RANDOM FOREST
   - Ensemble of decision trees with random feature selection
   - Uses majority voting for final prediction
   - Advantages: Handles non-linear relationships, robust to noise
   - Disadvantages: Less interpretable than single tree

4. DECISION TREE
   - Hierarchical binary splits based on feature thresholds
   - Advantages: Easy to interpret, fast prediction
   - Disadvantages: Prone to overfitting, sensitive to data changes

5. K-NEAREST NEIGHBORS (KNN)
   - Classifies based on majority class of k nearest samples
   - Advantages: Simple, no training phase
   - Disadvantages: Slow prediction, sensitive to irrelevant features
"""

def prepare_classification_data(image, ground_truth, indices, sample_fraction=0.1):
    """
    Prepare training and testing data for supervised classification.
    
    This function extracts features from the image and samples pixels for
    training and testing the classification algorithms.
    
    Parameters:
    -----------
    image : numpy.ndarray
        Preprocessed multispectral image
    ground_truth : numpy.ndarray
        Ground truth classification map
    indices : dict
        Dictionary of spectral indices
    sample_fraction : float
        Fraction of pixels to use as samples (default: 0.1)
    
    Returns:
    --------
    X_train : numpy.ndarray
        Training feature array
    X_test : numpy.ndarray
        Testing feature array
    y_train : numpy.ndarray
        Training labels
    y_test : numpy.ndarray
        Testing labels
    feature_names : list
        Names of features used
    """
    
    print("\n" + "-" * 60)
    print("PREPARING CLASSIFICATION DATA")
    print("-" * 60)
    
    rows, cols, bands = image.shape
    
    # -------------------------------------------------------------------------
    # Step 1: Create feature stack
    # -------------------------------------------------------------------------
    # Combine spectral bands with derived indices for richer feature space
    
    print("Step 1: Creating feature stack...")
    
    feature_names = ['Blue', 'Green', 'Red', 'NIR', 'SWIR1', 'SWIR2',
                     'NDVI', 'NDWI', 'NDBI', 'SAVI']
    
    # Stack all features
    feature_stack = np.dstack([
        image,                          # Original 6 bands
        indices['NDVI'][:, :, np.newaxis],
        indices['NDWI'][:, :, np.newaxis],
        indices['NDBI'][:, :, np.newaxis],
        indices['SAVI'][:, :, np.newaxis]
    ])
    
    print(f"  - Feature stack shape: {feature_stack.shape}")
    print(f"  - Features: {feature_names}")
    
    # -------------------------------------------------------------------------
    # Step 2: Reshape data for classification
    # -------------------------------------------------------------------------
    
    print("Step 2: Reshaping data...")
    
    # Flatten to 2D: (n_pixels, n_features)
    X_all = feature_stack.reshape(-1, feature_stack.shape[2])
    y_all = ground_truth.flatten()
    
    print(f"  - Total pixels: {len(y_all):,}")
    
    # -------------------------------------------------------------------------
    # Step 3: Sample pixels for training/testing
    # -------------------------------------------------------------------------
    # Using stratified sampling to maintain class proportions
    
    print(f"Step 3: Sampling {sample_fraction*100:.0f}% of pixels...")
    
    # Create sample indices
    n_samples = int(len(y_all) * sample_fraction)
    sample_indices = np.random.choice(len(y_all), size=n_samples, replace=False)
    
    X_sampled = X_all[sample_indices]
    y_sampled = y_all[sample_indices]
    
    # -------------------------------------------------------------------------
    # Step 4: Split into training and testing sets
    # -------------------------------------------------------------------------
    
    print("Step 4: Splitting into train/test sets (70/30)...")
    
    X_train, X_test, y_train, y_test = train_test_split(
        X_sampled, y_sampled,
        test_size=0.3,
        stratify=y_sampled,
        random_state=42
    )
    
    print(f"\nData preparation complete!")
    print(f"  - Training samples: {len(y_train):,}")
    print(f"  - Testing samples: {len(y_test):,}")
    
    # Show class distribution
    print("\nClass distribution in training set:")
    for class_id in range(len(CLASS_NAMES)):
        count = np.sum(y_train == class_id)
        print(f"  - {CLASS_NAMES[class_id]}: {count:,} samples ({count/len(y_train)*100:.1f}%)")
    
    return X_train, X_test, y_train, y_test, feature_names, X_all


def train_and_evaluate_classifiers(X_train, X_test, y_train, y_test, class_names):
    """
    Train multiple classification algorithms and evaluate their performance.
    
    This function implements and compares five common supervised classification
    algorithms used in remote sensing land cover mapping.
    
    Parameters:
    -----------
    X_train, X_test : numpy.ndarray
        Training and testing feature arrays
    y_train, y_test : numpy.ndarray
        Training and testing labels
    class_names : list
        Names of land cover classes
    
    Returns:
    --------
    classifiers : dict
        Dictionary of trained classifier objects
    results : dict
        Dictionary of classification results and metrics
    """
    
    print("\n" + "-" * 60)
    print("TRAINING AND EVALUATING CLASSIFICATION ALGORITHMS")
    print("-" * 60)
    
    # Standardize features for algorithms that benefit from it
    scaler = StandardScaler()
    X_train_scaled = scaler.fit_transform(X_train)
    X_test_scaled = scaler.transform(X_test)
    
    # Dictionary to store classifiers and results
    classifiers = {}
    results = {}
    
    # -------------------------------------------------------------------------
    # 1. Support Vector Machine (SVM)
    # -------------------------------------------------------------------------
    print("\n1. Training Support Vector Machine (SVM)...")
    print("   - Using RBF kernel for non-linear decision boundaries")
    print("   - class_weight='balanced' to handle class imbalance")
    
    svm_clf = SVC(
        kernel='rbf',           # Radial Basis Function kernel
        C=10.0,                 # Regularization parameter
        gamma='scale',          # Kernel coefficient
        class_weight='balanced', # Handle class imbalance
        random_state=42
    )
    svm_clf.fit(X_train_scaled, y_train)
    svm_pred = svm_clf.predict(X_test_scaled)
    
    classifiers['SVM'] = svm_clf
    results['SVM'] = {
        'predictions': svm_pred,
        'accuracy': accuracy_score(y_test, svm_pred),
        'kappa': cohen_kappa_score(y_test, svm_pred),
        'confusion_matrix': confusion_matrix(y_test, svm_pred)
    }
    print(f"   - Overall Accuracy: {results['SVM']['accuracy']*100:.2f}%")
    print(f"   - Kappa Coefficient: {results['SVM']['kappa']:.4f}")
    
    # -------------------------------------------------------------------------
    # 2. Random Forest
    # -------------------------------------------------------------------------
    print("\n2. Training Random Forest...")
    print("   - Using 100 trees for robust ensemble prediction")
    print("   - max_depth=20 to prevent overfitting")
    
    rf_clf = RandomForestClassifier(
        n_estimators=100,       # Number of trees in the forest
        max_depth=20,           # Maximum depth of trees
        min_samples_split=5,    # Minimum samples to split internal node
        min_samples_leaf=2,     # Minimum samples at leaf node
        class_weight='balanced',
        random_state=42,
        n_jobs=-1               # Use all CPU cores
    )
    rf_clf.fit(X_train, y_train)  # RF doesn't require scaling
    rf_pred = rf_clf.predict(X_test)
    
    classifiers['Random Forest'] = rf_clf
    results['Random Forest'] = {
        'predictions': rf_pred,
        'accuracy': accuracy_score(y_test, rf_pred),
        'kappa': cohen_kappa_score(y_test, rf_pred),
        'confusion_matrix': confusion_matrix(y_test, rf_pred),
        'feature_importance': rf_clf.feature_importances_
    }
    print(f"   - Overall Accuracy: {results['Random Forest']['accuracy']*100:.2f}%")
    print(f"   - Kappa Coefficient: {results['Random Forest']['kappa']:.4f}")
    
    # -------------------------------------------------------------------------
    # 3. Decision Tree
    # -------------------------------------------------------------------------
    print("\n3. Training Decision Tree...")
    print("   - Using Gini impurity for split criterion")
    print("   - max_depth=15 for interpretable tree structure")
    
    dt_clf = DecisionTreeClassifier(
        criterion='gini',       # Split quality measure
        max_depth=15,           # Maximum depth to prevent overfitting
        min_samples_split=10,
        min_samples_leaf=5,
        class_weight='balanced',
        random_state=42
    )
    dt_clf.fit(X_train, y_train)
    dt_pred = dt_clf.predict(X_test)
    
    classifiers['Decision Tree'] = dt_clf
    results['Decision Tree'] = {
        'predictions': dt_pred,
        'accuracy': accuracy_score(y_test, dt_pred),
        'kappa': cohen_kappa_score(y_test, dt_pred),
        'confusion_matrix': confusion_matrix(y_test, dt_pred)
    }
    print(f"   - Overall Accuracy: {results['Decision Tree']['accuracy']*100:.2f}%")
    print(f"   - Kappa Coefficient: {results['Decision Tree']['kappa']:.4f}")
    
    # -------------------------------------------------------------------------
    # 4. Gaussian Naive Bayes (simulates Maximum Likelihood)
    # -------------------------------------------------------------------------
    print("\n4. Training Gaussian Naive Bayes (Maximum Likelihood approach)...")
    print("   - Assumes features are independent given class")
    print("   - Provides probabilistic output")
    
    gnb_clf = GaussianNB()
    gnb_clf.fit(X_train, y_train)
    gnb_pred = gnb_clf.predict(X_test)
    
    classifiers['Naive Bayes'] = gnb_clf
    results['Naive Bayes'] = {
        'predictions': gnb_pred,
        'accuracy': accuracy_score(y_test, gnb_pred),
        'kappa': cohen_kappa_score(y_test, gnb_pred),
        'confusion_matrix': confusion_matrix(y_test, gnb_pred)
    }
    print(f"   - Overall Accuracy: {results['Naive Bayes']['accuracy']*100:.2f}%")
    print(f"   - Kappa Coefficient: {results['Naive Bayes']['kappa']:.4f}")
    
    # -------------------------------------------------------------------------
    # 5. K-Nearest Neighbors (KNN)
    # -------------------------------------------------------------------------
    print("\n5. Training K-Nearest Neighbors (KNN)...")
    print("   - Using k=5 neighbors for voting")
    print("   - distance-weighted voting for better accuracy")
    
    knn_clf = KNeighborsClassifier(
        n_neighbors=5,          # Number of neighbors to consider
        weights='distance',     # Weight by inverse distance
        metric='euclidean',     # Distance metric
        n_jobs=-1
    )
    knn_clf.fit(X_train_scaled, y_train)
    knn_pred = knn_clf.predict(X_test_scaled)
    
    classifiers['KNN'] = knn_clf
    results['KNN'] = {
        'predictions': knn_pred,
        'accuracy': accuracy_score(y_test, knn_pred),
        'kappa': cohen_kappa_score(y_test, knn_pred),
        'confusion_matrix': confusion_matrix(y_test, knn_pred)
    }
    print(f"   - Overall Accuracy: {results['KNN']['accuracy']*100:.2f}%")
    print(f"   - Kappa Coefficient: {results['KNN']['kappa']:.4f}")
    
    # -------------------------------------------------------------------------
    # Summary comparison
    # -------------------------------------------------------------------------
    print("\n" + "=" * 60)
    print("CLASSIFICATION RESULTS SUMMARY")
    print("=" * 60)
    print(f"{'Algorithm':<20} {'Overall Accuracy':<20} {'Kappa Coefficient':<20}")
    print("-" * 60)
    
    for name, result in sorted(results.items(), key=lambda x: x[1]['accuracy'], reverse=True):
        print(f"{name:<20} {result['accuracy']*100:>15.2f}% {result['kappa']:>19.4f}")
    
    return classifiers, results, scaler


def classify_entire_image(image, indices, classifier, scaler=None, use_scaling=False):
    """
    Apply trained classifier to classify the entire image.
    
    Parameters:
    -----------
    image : numpy.ndarray
        Preprocessed multispectral image
    indices : dict
        Dictionary of spectral indices
    classifier : object
        Trained classifier object
    scaler : StandardScaler
        Fitted scaler for feature normalization (if needed)
    use_scaling : bool
        Whether to apply scaling before classification
    
    Returns:
    --------
    classified_image : numpy.ndarray
        Classification result with shape (rows, cols)
    """
    
    rows, cols, bands = image.shape
    
    # Create feature stack
    feature_stack = np.dstack([
        image,
        indices['NDVI'][:, :, np.newaxis],
        indices['NDWI'][:, :, np.newaxis],
        indices['NDBI'][:, :, np.newaxis],
        indices['SAVI'][:, :, np.newaxis]
    ])
    
    # Reshape for classification
    X_all = feature_stack.reshape(-1, feature_stack.shape[2])
    
    # Apply scaling if needed
    if use_scaling and scaler is not None:
        X_all = scaler.transform(X_all)
    
    # Classify all pixels
    predictions = classifier.predict(X_all)
    
    # Reshape to image dimensions
    classified_image = predictions.reshape(rows, cols)
    
    return classified_image

# Prepare classification data
X_train, X_test, y_train, y_test, feature_names, X_all = prepare_classification_data(
    preprocessed_image, ground_truth_data, spectral_indices
)

# Train and evaluate classifiers
classifiers, classification_results, scaler = train_and_evaluate_classifiers(
    X_train, X_test, y_train, y_test, CLASS_NAMES
)

# Classify entire image using Random Forest (best performer typically)
print("\n" + "-" * 60)
print("CLASSIFYING ENTIRE IMAGE USING RANDOM FOREST")
print("-" * 60)

classified_image_rf = classify_entire_image(
    preprocessed_image, spectral_indices,
    classifiers['Random Forest'],
    scaler, use_scaling=False
)

print("Image classification complete!")

# =============================================================================
# SECTION 7: DEEP LEARNING - CONVOLUTIONAL NEURAL NETWORK (SIMPLIFIED)
# =============================================================================
"""
THEORETICAL BACKGROUND:
-----------------------
Deep learning, particularly Convolutional Neural Networks (CNNs), has 
revolutionized remote sensing image classification. Key concepts:

1. CONVOLUTIONAL LAYERS
   - Apply learnable filters to detect local patterns
   - Share weights across spatial locations (parameter efficiency)
   - Learn hierarchical features: edges → textures → objects

2. POOLING LAYERS
   - Reduce spatial dimensions while retaining important features
   - Provide translation invariance
   - Common types: max pooling, average pooling

3. ADVANTAGES FOR REMOTE SENSING
   - Automatically learns spatial context
   - Captures both spectral and spatial features
   - Can handle complex, non-linear relationships

4. CHALLENGES
   - Requires large training datasets
   - Computationally intensive
   - Prone to overfitting with limited data
   - Less interpretable than traditional methods

Note: For this tutorial, we provide a simplified demonstration without
TensorFlow/PyTorch to ensure compatibility. In practice, you would use
these frameworks for CNN implementation.
"""

def simple_cnn_demo(X_train, y_train, X_test, y_test, image_shape=(5, 5)):
    """
    Demonstrate CNN-like feature extraction using simple convolutions.
    
    This function simulates CNN behavior using scipy convolutions to show
    the concept of spatial feature learning. For real CNN implementation,
    use TensorFlow or PyTorch.
    
    Parameters:
    -----------
    X_train, X_test : numpy.ndarray
        Training and testing feature arrays
    y_train, y_test : numpy.ndarray
        Training and testing labels
    image_shape : tuple
        Shape of spatial neighborhood for feature extraction
    
    Returns:
    --------
    cnn_features_train : numpy.ndarray
        CNN-like extracted features for training
    cnn_accuracy : float
        Classification accuracy with CNN-like features
    """
    
    print("\n" + "-" * 60)
    print("DEEP LEARNING CONCEPT DEMONSTRATION")
    print("-" * 60)
    
    print("""
    In a real CNN implementation (using TensorFlow/Keras), you would:
    
    1. Define network architecture:
       model = Sequential([
           Conv2D(32, (3,3), activation='relu', input_shape=(patch_size, patch_size, bands)),
           MaxPooling2D((2,2)),
           Conv2D(64, (3,3), activation='relu'),
           MaxPooling2D((2,2)),
           Flatten(),
           Dense(128, activation='relu'),
           Dropout(0.5),
           Dense(num_classes, activation='softmax')
       ])
    
    2. Compile model:
       model.compile(optimizer='adam',
                    loss='categorical_crossentropy',
                    metrics=['accuracy'])
    
    3. Train model:
       model.fit(X_train_patches, y_train_onehot,
                epochs=50, batch_size=32, validation_split=0.2)
    
    4. Evaluate:
       accuracy = model.evaluate(X_test_patches, y_test_onehot)
    """)
    
    print("\nSimulating CNN-like spatial feature extraction...")
    
    # Define simple edge detection kernels (like first conv layer learns)
    kernels = [
        np.array([[-1, 0, 1], [-2, 0, 2], [-1, 0, 1]]),  # Vertical edges
        np.array([[-1, -2, -1], [0, 0, 0], [1, 2, 1]]),  # Horizontal edges
        np.array([[0, 1, 0], [1, -4, 1], [0, 1, 0]]),    # Laplacian
        np.array([[1, 1, 1], [1, 1, 1], [1, 1, 1]]) / 9  # Averaging (smoothing)
    ]
    
    print("Applying learned filters (convolution operation)...")
    print("This mimics what CNN convolutional layers do automatically.")
    
    # Note: In real implementation, we'd extract patches around each training pixel
    # Here we demonstrate the concept by adding synthetic spatial features
    
    # Add variance feature (simulates texture detection)
    var_feature_train = np.var(X_train, axis=1, keepdims=True)
    var_feature_test = np.var(X_test, axis=1, keepdims=True)
    
    # Add range feature (simulates contrast detection)
    range_feature_train = (np.max(X_train, axis=1) - np.min(X_train, axis=1))[:, np.newaxis]
    range_feature_test = (np.max(X_test, axis=1) - np.min(X_test, axis=1))[:, np.newaxis]
    
    # Combine with original features
    X_train_enhanced = np.hstack([X_train, var_feature_train, range_feature_train])
    X_test_enhanced = np.hstack([X_test, var_feature_test, range_feature_test])
    
    # Train Random Forest on enhanced features (simulating FC layers + softmax)
    rf_enhanced = RandomForestClassifier(n_estimators=100, max_depth=20, random_state=42, n_jobs=-1)
    rf_enhanced.fit(X_train_enhanced, y_train)
    
    pred_enhanced = rf_enhanced.predict(X_test_enhanced)
    accuracy_enhanced = accuracy_score(y_test, pred_enhanced)
    
    print(f"\nWith simulated spatial features:")
    print(f"  - Original features: {X_train.shape[1]}")
    print(f"  - Enhanced features: {X_train_enhanced.shape[1]}")
    print(f"  - Accuracy with enhanced features: {accuracy_enhanced*100:.2f}%")
    
    return X_train_enhanced, accuracy_enhanced

# Run CNN demonstration
X_train_cnn, cnn_accuracy = simple_cnn_demo(X_train, y_train, X_test, y_test)

# =============================================================================
# SECTION 8: POST-CLASSIFICATION PROCESSING
# =============================================================================
"""
THEORETICAL BACKGROUND:
-----------------------
Post-classification processing improves the quality of classification results
by reducing noise and enforcing spatial coherence. Common techniques include:

1. MAJORITY FILTERING
   - Replace each pixel with the most common class in its neighborhood
   - Removes salt-and-pepper noise
   - May smooth valid small features

2. SIEVING (MINIMUM MAPPING UNIT)
   - Remove small patches below a minimum size threshold
   - Enforces cartographic standards
   - Assigns removed pixels to surrounding dominant class

3. MORPHOLOGICAL OPERATIONS
   - Opening: Erosion followed by dilation (removes small bright spots)
   - Closing: Dilation followed by erosion (fills small dark holes)
   - Useful for cleaning up classification boundaries

4. RULE-BASED REFINEMENT
   - Apply expert knowledge and logical constraints
   - Example: Water cannot occur on steep slopes
   - Improves semantic consistency
"""

def post_classification_processing(classified_image, min_region_size=25):
    """
    Apply post-classification processing to improve classification quality.
    
    This function implements several common post-processing techniques to
    reduce noise and improve the spatial coherence of classification results.
    
    Parameters:
    -----------
    classified_image : numpy.ndarray
        Raw classification result with shape (rows, cols)
    min_region_size : int
        Minimum number of pixels for a valid region (default: 25)
    
    Returns:
    --------
    processed_image : numpy.ndarray
        Post-processed classification result
    processing_stats : dict
        Statistics about the processing applied
    """
    
    print("\n" + "-" * 60)
    print("POST-CLASSIFICATION PROCESSING")
    print("-" * 60)
    
    processed = classified_image.copy()
    stats = {}
    
    # -------------------------------------------------------------------------
    # Step 1: Majority Filter (Modal Filter)
    # -------------------------------------------------------------------------
    print("Step 1: Applying majority filter (5x5 window)...")
    
    # Custom majority filter implementation
    def majority_filter(img, size=5):
        """Apply majority filter to classification image."""
        from scipy.ndimage import generic_filter
        
        def mode_filter(values):
            """Return mode of values."""
            values = values.astype(int)
            counts = np.bincount(values)
            return np.argmax(counts)
        
        return generic_filter(img.astype(float), mode_filter, size=size)
    
    processed_majority = majority_filter(processed, size=5)
    
    # Count changed pixels
    changed_pixels = np.sum(processed != processed_majority)
    stats['majority_filter_changes'] = changed_pixels
    print(f"   - Pixels changed: {changed_pixels:,} ({changed_pixels/processed.size*100:.2f}%)")
    
    processed = processed_majority.astype(np.int32)
    
    # -------------------------------------------------------------------------
    # Step 2: Small Region Removal (Sieving)
    # -------------------------------------------------------------------------
    print(f"Step 2: Removing regions smaller than {min_region_size} pixels...")
    
    from scipy.ndimage import label, find_objects
    
    # Label connected components for each class
    small_regions_removed = 0
    
    for class_id in np.unique(processed):
        # Create binary mask for this class
        class_mask = (processed == class_id)
        
        # Label connected components
        labeled, num_features = label(class_mask)
        
        # Find and process each region
        for region_id in range(1, num_features + 1):
            region_mask = (labeled == region_id)
            region_size = np.sum(region_mask)
            
            if region_size < min_region_size:
                # Find neighboring class to assign
                # Dilate the region and find most common neighbor
                dilated = ndimage.binary_dilation(region_mask, iterations=2)
                neighbor_mask = dilated & ~region_mask
                
                if np.sum(neighbor_mask) > 0:
                    neighbor_classes = processed[neighbor_mask]
                    neighbor_mode = np.bincount(neighbor_classes).argmax()
                    processed[region_mask] = neighbor_mode
                    small_regions_removed += 1
    
    stats['small_regions_removed'] = small_regions_removed
    print(f"   - Small regions removed: {small_regions_removed}")
    
    # -------------------------------------------------------------------------
    # Step 3: Boundary Smoothing using morphological operations
    # -------------------------------------------------------------------------
    print("Step 3: Smoothing boundaries with morphological operations...")
    
    # Apply opening then closing to each class separately
    structuring_element = ndimage.generate_binary_structure(2, 1)
    
    for class_id in np.unique(processed):
        class_mask = (processed == class_id)
        
        # Opening removes small bright spots
        opened = ndimage.binary_opening(class_mask, structuring_element, iterations=1)
        
        # Closing fills small holes
        closed = ndimage.binary_closing(opened, structuring_element, iterations=1)
        
        # Update only where class was originally present
        processed[class_mask] = -1  # Temporary mark
        processed[closed] = class_id
    
    # Fill any gaps created
    processed[processed == -1] = classified_image[processed == -1]
    
    # -------------------------------------------------------------------------
    # Final statistics
    # -------------------------------------------------------------------------
    total_changes = np.sum(classified_image != processed)
    stats['total_changes'] = total_changes
    stats['change_percentage'] = total_changes / processed.size * 100
    
    print(f"\nPost-processing complete!")
    print(f"   - Total pixels changed: {total_changes:,} ({stats['change_percentage']:.2f}%)")
    
    return processed, stats

# Apply post-processing
classified_processed, post_stats = post_classification_processing(classified_image_rf)

# =============================================================================
# SECTION 9: ACCURACY ASSESSMENT
# =============================================================================
"""
THEORETICAL BACKGROUND:
-----------------------
Accuracy assessment is crucial for evaluating the reliability of classification
results. Key concepts and metrics include:

1. CONFUSION MATRIX (ERROR MATRIX)
   - Compares reference data (columns) with classification results (rows)
   - Diagonal elements: correctly classified pixels
   - Off-diagonal elements: misclassified pixels

2. OVERALL ACCURACY (OA)
   - Total correctly classified pixels / Total pixels
   - Simple and intuitive but can be misleading with class imbalance

3. PRODUCER'S ACCURACY (PA) / RECALL
   - Correctly classified in class / Total reference pixels in class
   - Indicates probability of reference pixel being correctly classified
   - Related to omission error: 100% - PA = omission error

4. USER'S ACCURACY (UA) / PRECISION
   - Correctly classified in class / Total classified as that class
   - Indicates probability that classified pixel is correct
   - Related to commission error: 100% - UA = commission error

5. KAPPA COEFFICIENT
   - Measures agreement beyond chance
   - Values: -1 to 1 (1 = perfect agreement, 0 = chance agreement)
   - Accounts for expected agreement due to class frequencies

6. F1 SCORE
   - Harmonic mean of precision and recall
   - F1 = 2 * (Precision * Recall) / (Precision + Recall)
   - Balances user's and producer's accuracy
"""

def comprehensive_accuracy_assessment(y_true, y_pred, class_names):
    """
    Perform comprehensive accuracy assessment of classification results.
    
    This function calculates and displays all standard accuracy metrics
    used in remote sensing classification assessment.
    
    Parameters:
    -----------
    y_true : numpy.ndarray
        Reference (ground truth) labels
    y_pred : numpy.ndarray
        Predicted (classified) labels
    class_names : list
        Names of land cover classes
    
    Returns:
    --------
    metrics : dict
        Dictionary containing all calculated metrics
    """
    
    print("\n" + "=" * 80)
    print("COMPREHENSIVE ACCURACY ASSESSMENT")
    print("=" * 80)
    
    metrics = {}
    
    # -------------------------------------------------------------------------
    # Step 1: Calculate Confusion Matrix
    # -------------------------------------------------------------------------
    print("\n1. CONFUSION MATRIX")
    print("-" * 60)
    
    cm = confusion_matrix(y_true, y_pred)
    metrics['confusion_matrix'] = cm
    
    # Display confusion matrix
    print(f"\n{'Reference →':<15}", end='')
    for name in class_names:
        print(f"{name[:8]:<10}", end='')
    print(f"{'Row Total':<10}")
    print("-" * (15 + 10 * (len(class_names) + 1)))
    
    for i, name in enumerate(class_names):
        print(f"{name[:12]:<15}", end='')
        for j in range(len(class_names)):
            print(f"{cm[i, j]:<10}", end='')
        print(f"{cm[i, :].sum():<10}")
    
    print("-" * (15 + 10 * (len(class_names) + 1)))
    print(f"{'Col Total':<15}", end='')
    for j in range(len(class_names)):
        print(f"{cm[:, j].sum():<10}", end='')
    print(f"{cm.sum():<10}")
    
    # -------------------------------------------------------------------------
    # Step 2: Calculate Overall Accuracy
    # -------------------------------------------------------------------------
    print("\n\n2. OVERALL ACCURACY")
    print("-" * 60)
    
    overall_accuracy = accuracy_score(y_true, y_pred)
    metrics['overall_accuracy'] = overall_accuracy
    
    correct = np.diag(cm).sum()
    total = cm.sum()
    
    print(f"Correctly classified pixels: {correct:,}")
    print(f"Total pixels: {total:,}")
    print(f"Overall Accuracy: {overall_accuracy * 100:.2f}%")
    
    # -------------------------------------------------------------------------
    # Step 3: Calculate Per-Class Accuracies
    # -------------------------------------------------------------------------
    print("\n\n3. PER-CLASS ACCURACY METRICS")
    print("-" * 60)
    
    producers_accuracy = []
    users_accuracy = []
    f1_scores = []
    
    print(f"\n{'Class':<15}{'Producer Acc.':<15}{'User Acc.':<15}{'F1 Score':<15}{'Support':<10}")
    print("-" * 70)
    
    for i, name in enumerate(class_names):
        # Producer's Accuracy (Recall): TP / (TP + FN) = diagonal / column sum
        pa = cm[i, i] / cm[:, i].sum() if cm[:, i].sum() > 0 else 0
        producers_accuracy.append(pa)
        
        # User's Accuracy (Precision): TP / (TP + FP) = diagonal / row sum
        ua = cm[i, i] / cm[i, :].sum() if cm[i, :].sum() > 0 else 0
        users_accuracy.append(ua)
        
        # F1 Score
        f1 = 2 * (pa * ua) / (pa + ua) if (pa + ua) > 0 else 0
        f1_scores.append(f1)
        
        # Support (number of true instances)
        support = cm[:, i].sum()
        
        print(f"{name[:12]:<15}{pa*100:>10.2f}% {ua*100:>13.2f}% {f1:>12.4f} {support:>10,}")
    
    metrics['producers_accuracy'] = producers_accuracy
    metrics['users_accuracy'] = users_accuracy
    metrics['f1_scores'] = f1_scores
    
    # -------------------------------------------------------------------------
    # Step 4: Calculate Omission and Commission Errors
    # -------------------------------------------------------------------------
    print("\n\n4. ERROR ANALYSIS")
    print("-" * 60)
    
    omission_errors = [1 - pa for pa in producers_accuracy]
    commission_errors = [1 - ua for ua in users_accuracy]
    
    print(f"\n{'Class':<15}{'Omission Error':<18}{'Commission Error':<18}")
    print("-" * 50)
    
    for i, name in enumerate(class_names):
        print(f"{name[:12]:<15}{omission_errors[i]*100:>13.2f}% {commission_errors[i]*100:>17.2f}%")
    
    metrics['omission_errors'] = omission_errors
    metrics['commission_errors'] = commission_errors
    
    # -------------------------------------------------------------------------
    # Step 5: Calculate Kappa Coefficient
    # -------------------------------------------------------------------------
    print("\n\n5. KAPPA COEFFICIENT")
    print("-" * 60)
    
    kappa = cohen_kappa_score(y_true, y_pred)
    metrics['kappa'] = kappa
    
    # Calculate expected accuracy by chance
    row_totals = cm.sum(axis=1)
    col_totals = cm.sum(axis=0)
    n = cm.sum()
    expected_accuracy = np.sum(row_totals * col_totals) / (n ** 2)
    
    print(f"Observed Agreement (Po): {overall_accuracy:.4f}")
    print(f"Expected Agreement (Pe): {expected_accuracy:.4f}")
    print(f"Kappa Coefficient: {kappa:.4f}")
    
    # Interpret Kappa
    if kappa >= 0.81:
        interpretation = "Almost Perfect Agreement"
    elif kappa >= 0.61:
        interpretation = "Substantial Agreement"
    elif kappa >= 0.41:
        interpretation = "Moderate Agreement"
    elif kappa >= 0.21:
        interpretation = "Fair Agreement"
    elif kappa >= 0.0:
        interpretation = "Slight Agreement"
    else:
        interpretation = "Poor Agreement"
    
    print(f"Interpretation: {interpretation}")
    
    # -------------------------------------------------------------------------
    # Step 6: Summary Report
    # -------------------------------------------------------------------------
    print("\n\n6. SUMMARY REPORT")
    print("=" * 60)
    
    print(f"""
    Classification Accuracy Assessment Summary
    ------------------------------------------
    Overall Accuracy:     {overall_accuracy * 100:.2f}%
    Kappa Coefficient:    {kappa:.4f}
    
    Mean Producer's Accuracy: {np.mean(producers_accuracy) * 100:.2f}%
    Mean User's Accuracy:     {np.mean(users_accuracy) * 100:.2f}%
    Mean F1 Score:            {np.mean(f1_scores):.4f}
    
    Best Classified Class:    {class_names[np.argmax(f1_scores)]} (F1: {max(f1_scores):.4f})
    Worst Classified Class:   {class_names[np.argmin(f1_scores)]} (F1: {min(f1_scores):.4f})
    """)
    
    return metrics


def visualize_classification_results(ground_truth, classified, processed, 
                                    metrics, class_names, class_colors):
    """
    Create comprehensive visualization of classification results and accuracy.
    
    Parameters:
    -----------
    ground_truth : numpy.ndarray
        Reference ground truth classification
    classified : numpy.ndarray
        Raw classification result
    processed : numpy.ndarray
        Post-processed classification result
    metrics : dict
        Accuracy metrics dictionary
    class_names : list
        Names of land cover classes
    class_colors : list
        Colors for each class
    """
    
    fig = plt.figure(figsize=(20, 16))
    
    # Create custom colormap
    cmap = mcolors.ListedColormap(class_colors)
    bounds = np.arange(-0.5, len(class_names), 1)
    norm = mcolors.BoundaryNorm(bounds, cmap.N)
    
    # Row 1: Classification Maps
    ax1 = fig.add_subplot(2, 3, 1)
    ax1.imshow(ground_truth, cmap=cmap, norm=norm)
    ax1.set_title('Ground Truth', fontsize=14, fontweight='bold')
    ax1.axis('off')
    
    ax2 = fig.add_subplot(2, 3, 2)
    ax2.imshow(classified, cmap=cmap, norm=norm)
    ax2.set_title('Classification Result', fontsize=14, fontweight='bold')
    ax2.axis('off')
    
    ax3 = fig.add_subplot(2, 3, 3)
    ax3.imshow(processed, cmap=cmap, norm=norm)
    ax3.set_title('After Post-Processing', fontsize=14, fontweight='bold')
    ax3.axis('off')
    
    # Add legend
    legend_patches = [Patch(facecolor=class_colors[i], label=class_names[i]) 
                      for i in range(len(class_names))]
    ax3.legend(handles=legend_patches, loc='lower right', fontsize=9)
    
    # Row 2: Error Maps and Metrics
    
    # Misclassification map
    ax4 = fig.add_subplot(2, 3, 4)
    error_map = (ground_truth != processed).astype(int)
    ax4.imshow(error_map, cmap='RdYlGn_r')
    ax4.set_title(f'Misclassification Map\n(Errors in Red)', fontsize=14, fontweight='bold')
    ax4.axis('off')
    
    # Confusion Matrix Heatmap
    ax5 = fig.add_subplot(2, 3, 5)
    cm = metrics['confusion_matrix']
    cm_normalized = cm.astype('float') / cm.sum(axis=1)[:, np.newaxis]
    
    im = ax5.imshow(cm_normalized, cmap='Blues', vmin=0, vmax=1)
    ax5.set_xticks(np.arange(len(class_names)))
    ax5.set_yticks(np.arange(len(class_names)))
    ax5.set_xticklabels([n[:8] for n in class_names], fontsize=9)
    ax5.set_yticklabels([n[:8] for n in class_names], fontsize=9)
    ax5.set_xlabel('Reference', fontsize=11)
    ax5.set_ylabel('Classified', fontsize=11)
    ax5.set_title('Normalized Confusion Matrix', fontsize=14, fontweight='bold')
    
    # Add text annotations
    for i in range(len(class_names)):
        for j in range(len(class_names)):
            text = f'{cm_normalized[i, j]:.2f}'
            color = 'white' if cm_normalized[i, j] > 0.5 else 'black'
            ax5.text(j, i, text, ha='center', va='center', color=color, fontsize=9)
    
    plt.colorbar(im, ax=ax5, fraction=0.046)
    
    # Per-class accuracy bar chart
    ax6 = fig.add_subplot(2, 3, 6)
    
    x = np.arange(len(class_names))
    width = 0.35
    
    bars1 = ax6.bar(x - width/2, [pa*100 for pa in metrics['producers_accuracy']], 
                   width, label="Producer's Accuracy", color='steelblue')
    bars2 = ax6.bar(x + width/2, [ua*100 for ua in metrics['users_accuracy']], 
                   width, label="User's Accuracy", color='coral')
    
    ax6.set_xlabel('Land Cover Class', fontsize=11)
    ax6.set_ylabel('Accuracy (%)', fontsize=11)
    ax6.set_title('Per-Class Accuracy Comparison', fontsize=14, fontweight='bold')
    ax6.set_xticks(x)
    ax6.set_xticklabels([n[:8] for n in class_names], fontsize=9)
    ax6.legend(fontsize=9)
    ax6.set_ylim(0, 105)
    ax6.grid(axis='y', alpha=0.3)
    
    # Add value labels on bars
    for bar in bars1:
        height = bar.get_height()
        ax6.annotate(f'{height:.1f}',
                    xy=(bar.get_x() + bar.get_width() / 2, height),
                    xytext=(0, 3), textcoords="offset points",
                    ha='center', va='bottom', fontsize=8)
    
    for bar in bars2:
        height = bar.get_height()
        ax6.annotate(f'{height:.1f}',
                    xy=(bar.get_x() + bar.get_width() / 2, height),
                    xytext=(0, 3), textcoords="offset points",
                    ha='center', va='bottom', fontsize=8)
    
    # Add overall metrics text box
    textstr = f"Overall Accuracy: {metrics['overall_accuracy']*100:.2f}%\n"
    textstr += f"Kappa: {metrics['kappa']:.4f}"
    props = dict(boxstyle='round', facecolor='wheat', alpha=0.5)
    ax6.text(0.02, 0.98, textstr, transform=ax6.transAxes, fontsize=10,
            verticalalignment='top', bbox=props)
    
    plt.tight_layout()
    plt.savefig('04_classification_results.png', dpi=150, bbox_inches='tight')
    plt.close()
    
    print("\nClassification results visualization saved as '04_classification_results.png'")

# Perform accuracy assessment on post-processed result
y_true_flat = ground_truth_data.flatten()
y_pred_flat = classified_processed.flatten()

# Sample for faster assessment
sample_indices = np.random.choice(len(y_true_flat), size=50000, replace=False)
y_true_sample = y_true_flat[sample_indices]
y_pred_sample = y_pred_flat[sample_indices]

accuracy_metrics = comprehensive_accuracy_assessment(y_true_sample, y_pred_sample, CLASS_NAMES)

# Visualize results
visualize_classification_results(
    ground_truth_data, classified_image_rf, classified_processed,
    accuracy_metrics, CLASS_NAMES, CLASS_COLORS
)

# =============================================================================
# SECTION 10: FINAL SUMMARY AND CONCLUSIONS
# =============================================================================

print("\n" + "=" * 80)
print("TUTORIAL COMPLETE - FINAL SUMMARY")
print("=" * 80)

print("""
This comprehensive tutorial covered the complete workflow for remote sensing
data analysis and land cover classification:

1. DATA SIMULATION AND EXPLORATION
   - Generated realistic 6-band multispectral imagery (512x512 pixels)
   - Created 5 land cover classes with characteristic spectral signatures
   - Visualized data using true color and false color composites

2. IMAGE PREPROCESSING
   - Applied radiometric corrections (destriping, atmospheric correction)
   - Demonstrated geometric correction concepts
   - Implemented noise reduction filters

3. IMAGE ENHANCEMENT
   - Calculated spectral indices (NDVI, NDWI, NDBI, SAVI, EVI)
   - Applied spatial filters (mean, median, Sobel edge detection)
   - Performed Principal Component Analysis (PCA)

4. SUPERVISED CLASSIFICATION
   - Implemented 5 classification algorithms:
     * Support Vector Machine (SVM)
     * Random Forest
     * Decision Tree
     * Naive Bayes (Maximum Likelihood approach)
     * K-Nearest Neighbors (KNN)
   - Compared algorithm performance

5. DEEP LEARNING CONCEPTS
   - Explained CNN architecture and principles
   - Demonstrated spatial feature extraction concepts

6. POST-CLASSIFICATION PROCESSING
   - Applied majority filtering for noise reduction
   - Removed small regions below minimum mapping unit
   - Smoothed boundaries using morphological operations

7. ACCURACY ASSESSMENT
   - Generated confusion matrix
   - Calculated overall accuracy and Kappa coefficient
   - Computed producer's and user's accuracies
   - Analyzed omission and commission errors

OUTPUT FILES GENERATED:
----------------------
1. 01_data_visualization.png - Original data visualization
2. 02_preprocessing_results.png - Preprocessing comparison
3. 03_enhancement_results.png - Enhancement techniques results
4. 04_classification_results.png - Final classification and accuracy

For further learning, explore:
- Real satellite data from USGS Earth Explorer or ESA Copernicus Hub
- Deep learning frameworks (TensorFlow, PyTorch) for CNN implementation
- Object-based image analysis (OBIA) techniques
- Time series analysis for change detection
""")

print("=" * 80)
print("END OF TUTORIAL")
print("=" * 80)
